module.exports = (app) => {
    const user = require('../controller/userController');

    app.post('/user',user.create);
    app.delete('/user/:userName',user.delete);
}