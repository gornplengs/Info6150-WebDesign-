const User = require('../model/user');

exports.create = (req,res) => {
    const user = new User({
        userName : req.body.userName,
        password : req.body.password
    });

    user.save().
    then(() => {
        res.send({'message':'User created successfully'});
    });
};

exports.delete = (req,res) => {
    User.findOneAndRemove(req.params.userName).
    then(user => {
        res.send({'message':'user deleted successfully'});
    }); 
};